<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');

		$config['registrasi_view']      = 'https://dev-it.kopkarbsm.co.id/mykopkarbsm/file.registrasi.567/';
		$config['upload_path']          = './file.upload.1/';
		$config['folder']          		= 'file.upload.1/';
		$config['folder_tiket']         = 'https://dev-it.kopkarbsm.co.id/mykopkarbsm/file.upload.dokumen/';
		$config['allowed_types']        = 'gif|jpg|jpeg|png|xls|xlsx|pdf|doc|docx';
		$config['overwrite']			= true;
		$config['max_size']             = '100000'; //
?>