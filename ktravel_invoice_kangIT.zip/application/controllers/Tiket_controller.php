<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Tiket_controller extends MY_Controller
{
	private $filename = "import_data"; // Kita tentukan nama filenya
    public function __construct()
    {
        parent::__construct();
        $this->load->model("Customer_model");
        $this->load->model("Divisi_model");
        $this->load->model("Perusahaan_model");
        $this->load->model("Tiket_model");
        $this->load->library('form_validation');
    }

    public function index()
    {
        $data["perusahaan"] = $this->Perusahaan_model->getAll();
        $data["customer"] = $this->Customer_model->getAll();
        $data["tiket"] = $this->Tiket_model->getAll();
        $data["dataDivisi"] = $this->Divisi_model->getAll();
        
        $this->load->view("tiket/lihat_tiket", $data);
    }

    public function add()
    {
        // echo 'hello';die();
        $perusahaan = $this->Perusahaan_model;
        $validation = $this->form_validation;
		    $validation->set_rules($perusahaan->rules());
        if ($validation->run()) {
            $perusahaan->save();
            $this->session->set_flashdata('success', 'Tambah Perusahaan Berhasil Disimpan');
            redirect('Tiket_controller');
        }

        $this->load->view("perusahaan/lihat_perusahaan");
    }

  //   public function edit($id){

  //   	$faq = $this->Customer_model; //object model
  //       $validation = $this->form_validation; //object validasi
  //       $validation->set_rules($faq->rules()); //terapkan rules di Customer_model.php

  //       if ($validation->run()) { //lakukan validasi form
  //           $faq->update($id); // update data
  //           $this->session->set_flashdata('success', 'Data FAQ Berhasil Diubah');
  //           redirect('Tiket_controller');
  //       }

  //       // $faq= $this->Customer_model->getById($id);
		// $data['list_divisi'] = $this->Customer_model->getById($id);
  //       $this->load->view('customer/lihat_customer', $data);
  //   }

    public function edit(){
    	$dataPerusahaan = $this->input->post();
    	$id 	= $dataPerusahaan['perusahaan_id'];
    	$perusahaan = $this->Perusahaan_model; //object model
        $validation = $this->form_validation; //object validasi
        $validation->set_rules($perusahaan->rules()); //terapkan rules di Customer_model.php

        if ($validation->run()) { //lakukan validasi form
            $perusahaan->update($id); // update data
            $this->session->set_flashdata('success', 'Data Perusahaan Berhasil Diubah');
            redirect('Tiket_controller');
        }
    }

	public function approve($id){

    	$faq = $this->Customer_model; //object model
        $validation = $this->form_validation; //object validasi
        $validation->set_rules($faq->rules()); //terapkan rules di Customer_model.php

        if ($validation->run()) { //lakukan validasi form
            $faq->approve($id); // approve data
            // $this->session->set_flashdata('success', 'Itu akan jadi proses Approve');
            redirect('Tiket_controller');
        }

        // $faq= $this->Customer_model->getById($id);
		$data['faq'] = $this->Customer_model->getById($id);
        $this->load->view('customer/approve_faq', $data);
    }

    public function delete($id){
	    $this->Tiket_model->delete($id); // Panggil fungsi delete() yang ada di SiswaModel.php
	    $this->session->set_flashdata('success', 'Data Perusahaan Berhasil Dihapus');
	    redirect('Tiket_controller');
	}

    public function detailTiketInvoice(){
        $divisi_id = $this->input->post('divisiid');
        $no_invoice = $this->input->post('noinvoicedetail');
        $tiket = $this->Tiket_model;

        $data['tiket'] = $tiket->invoiceListTiket($no_invoice, $divisi_id);
        $this->load->view('invoice/data_detail', $data);
    }

    public function genereate_list_tiket(){
        $divisi_id = $this->input->post('divisi_id');
        $from_periode = $this->input->post('from');
        $to_periode = $this->input->post('to');

        $tiket = $this->Tiket_model->generateListTiket($divisi_id, $from_periode, $to_periode);

        echo json_encode($tiket);
    }

    public function removeTiketFromInvoice(){
        $tiket = $this->Tiket_model;
        $tiket_id = $this->input->post('tiket_id');
        $tiket->removeTiketFromInvoice($tiket_id);

        echo json_encode('SUCCESS, tiket ID : '.$tiket_id);
    }

}
