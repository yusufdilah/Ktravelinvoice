<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
* 
*/
class Tiket_model extends CI_Model
{
	
	private $_table= "tiket";

	// public $id;	
	// public $judul;
	// public $isi;
	// public $status;
	// public $seq;

	public function rules()
	{
		return [
			['field' => 'tgl_berangkat',
			'label' => 'tgl_berangkat',
			'rules' => 'required']
		];
	}

	public function getALL(){
		$this->db->select('*');
		$this->db->from($this->_table);
		$this->db->order_by('created_date', SORT_DESC);
		$data = $this->db->get();
				// print_r($this->db->last_query());die();
		return $data->result();
	}

	public function getById($id){
		// return $this->db->get_where($this->_table, ["perusahaan_id" => $id])->row();
		$this->db->select($this->_table.'.*,customer.nama_customer, customer.nip_customer, divisi.nama_divisi')
		->from($this->_table)
		->join('customer', 'customer.customer_id='.$this->_table.'.customer')
		->join('divisi', 'divisi.divisi_id='.$this->_table.'.divisi')
		->where($this->_table.'.tiket_id', $id);
		$data = $this->db->get();
		return $data->row();
	}

	public function save(){
		$post = $this->input->post();
		$session_nasabah = $this->session->userdata('token_nasabah');
		// echo '<pre>';
		// var_dump($post);
		// echo '</pre>';
		// die();
		// $this->faq_id = uniqid();
		$this->tgl_berangkat = $post["tgl_berangkat"];
		$this->divisi = $post["divisi"];
		$this->akomodasi = $post["akomodasi"];
		$this->maskapai = $post["maskapai"];
		$this->hotel = $post["hotel"];
		$this->alamat_hotel = $post["alamat_hotel"];
		$this->route = $post["route"];
		$this->vendor = $post["vendor"];
		$this->hpp = $post["hpp"];
		$this->service_fee = $post["service_fee"];
		$this->biaya_lain = $post["biaya_lain"];
		$this->harga_jual = $post["harga_jual"];
		$this->created_by = $session_nasabah;
		$this->db->insert($this->_table, $this);
	}


	public function update($id){
		$session_nasabah = $this->session->userdata('token_nasabah');
		date_default_timezone_set("Asia/Jakarta");   
        $updated_date = date('Y-m-d H:i:s');
		$data = array(
			"nm_perusahaan" => $this->input->post('nm_perusahaan'),
			"alamat_perusahaan" => $this->input->post('alamat_perusahaan'),
            "no_telepon" => $this->input->post('no_telepon'),
            "email" => $this->input->post('email'),
            "bank_cabang" => $this->input->post('bank_cabang'),
            "no_rekening" => $this->input->post('no_rekening'),
            "atas_nama" => $this->input->post('atas_nama'),
            "penanda_tangan" => $this->input->post('penanda_tangan'),
            "updated_by" => $session_nasabah,
            "updated_date" => $updated_date
         );   
		$this->db->where('perusahaan_id', $id);
	    $this->db->update('perusahaan', $data); // Untuk mengeksekusi perintah update data
	}

	

	public function delete($id){
		$this->db->where('tiket_id', $id);
    	$this->db->delete('tiket'); // Untuk mengeksekusi perintah delete data
	}



	// Buat sebuah fungsi untuk melakukan insert lebih dari 1 data
	public function insert_multiple($data){
		$this->db->insert_batch('faq', $data);
	}

	// generate list tiket untuk add invoice
	public function generateListTiket($divisi_id, $from, $to){
		$this->db->select($this->_table.'.*, divisi.nama_divisi, 
		divisi.nm_group_head, maskapai.nama_maskapai, route.kd_route, vendor.nm_vendor, customer.nama_customer, customer.nip_customer');
		$this->db->from($this->_table);
		$this->db->join('divisi', 'divisi.divisi_id='.$this->_table.'.divisi');
		$this->db->join('maskapai', 'maskapai.maskapai_id=tiket.maskapai');
		$this->db->join('route', 'route.route_id=tiket.route');
		$this->db->join('vendor', 'vendor.vendor_id=tiket.vendor');
		$this->db->join('customer', 'customer.customer_id=tiket.customer');
		$this->db->where('tiket.tgl_issued>=',$from);
		$this->db->where('tiket.tgl_issued<=', $to);
		$this->db->where('tiket.divisi=', $divisi_id);
		$data = $this->db->get();

		return $data->result();
	}

	// mengambil data tiker juga untk data yang sudah di input;
	public function invoiceListTiket($no_invoice, $divisi_id){
		$this->db->select($this->_table.'.*, divisi.nama_divisi, 
		divisi.nm_group_head, maskapai.nama_maskapai, route.kd_route, vendor.nm_vendor, customer.nama_customer, customer.nip_customer');
		$this->db->from($this->_table);
		$this->db->join('divisi', 'divisi.divisi_id='.$this->_table.'.divisi');
		$this->db->join('maskapai', 'maskapai.maskapai_id=tiket.maskapai');
		$this->db->join('route', 'route.route_id=tiket.route');
		$this->db->join('vendor', 'vendor.vendor_id=tiket.vendor');
		$this->db->join('customer', 'customer.customer_id=tiket.customer');
		$this->db->where($this->_table.'.no_invoice', $no_invoice);
		$this->db->where($this->_table.'.divisi', $divisi_id);
		
		$data = $this->db->get();

		return $data->result();
	}

	// hapus relasi dengan invoice yang dihapus
	public function removeTiketFromInvoice($id){
		$this->db->where('tiket_id', $id);
    	$this->db->update($this->_table, ['no_invoice'=>null]);
	}
}
?>
