 <footer class="main-footer">
 	<div class="pull-right hidden-xs">
 		<b>Version</b> 1.0.0
 	</div>
 	<strong>Copyright &copy; 2021  <a href="https://kopkarbsm.co.id/" target="_blank">Kopkar</a>.</strong> All rights
 	reserved.
 </footer>